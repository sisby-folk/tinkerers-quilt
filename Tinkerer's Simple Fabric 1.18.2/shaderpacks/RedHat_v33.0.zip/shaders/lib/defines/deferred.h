
// Please, DO NOT touch these values, unless you know what you're doing, and you're experienced with optifine

#define SATURATION 0.0          // Saturation               [-1.0 -0.9 -0.8 -0.7 -0.6 -0.5 -0.4 -0.3 -0.2 -0.1 0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]