java -Xmx2048M -Xms2048M -javaagent:unsup.jar -Dloader.debug.loadLate=origins -jar quilt-server-launch.jar nogui
pause
